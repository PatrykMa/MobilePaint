package com.example.patryk.mobilepaint

import android.app.AlertDialog
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Point
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.MotionEvent
import android.view.View.inflate
import android.widget.ImageView
import com.example.patryk.mobilepaint.drawable.DrawableType

class MainActivity : AppCompatActivity() {



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        getSupportActionBar()?.setDisplayShowCustomEnabled(true)
        getSupportActionBar()?.setCustomView(R.layout.app_bar)
        val drawView = findViewById<DrawView>(R.id.drawView)
        findViewById<ImageView>(R.id.line).setOnClickListener {
            drawView.drawElementType =DrawableType.Line
        }
        findViewById<ImageView>(R.id.path).setOnClickListener {
            drawView.drawElementType =DrawableType.FingerPath
        }
        findViewById<ImageView>(R.id.circle).setOnClickListener {
            drawView.drawElementType =DrawableType.Circle
            createDialog()
        }
    }
    fun createDialog(){
       // ColorPalletDialog(this).show()


    }





}
