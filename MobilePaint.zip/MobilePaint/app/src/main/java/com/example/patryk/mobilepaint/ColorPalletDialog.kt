package com.example.patryk.mobilepaint

import android.content.Context
import android.os.Bundle
import android.support.v7.app.AlertDialog
import android.view.KeyEvent.KEYCODE_BACK
import android.R.attr.description
import android.widget.TextView
import android.R.attr.data
import android.content.DialogInterface
import android.view.KeyEvent
import android.view.LayoutInflater



class ColorPalletDialog(context: Context): AlertDialog(context) {

    var color = 0

    var onPositiveClose:()->Unit = {}
    var onNegativeEnd: ()->Unit = {}
    override fun onCreate(savedInstanceState: Bundle?) {
        val content = LayoutInflater.from(context).inflate(R.layout.color_dialog, null)
        setView(content)
        setTitle("Some Title")
        setMessage("Some Message")
        setButton(
            DialogInterface.BUTTON_POSITIVE, "Ok"
        ) { dialog, which -> onPositiveClose() }
        setButton( DialogInterface.BUTTON_NEGATIVE, "Ok"){ dialog, which -> onNegativeEnd() }
        //(content.findViewById(R.id.data) as TextView).setText(R.string.some_custom_data)
        //(content.findViewById(R.id.description) as TextView).text = context.getString(R.string.description)
        setCancelable(false)
        setOnKeyListener { dialog, keyCode, event -> keyCode == KeyEvent.KEYCODE_BACK }
        super.onCreate(savedInstanceState)
    }
}