package com.example.patryk.mobilepaint.drawable.elements

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Point
import com.example.patryk.mobilepaint.drawable.Drawable
import com.example.patryk.mobilepaint.drawable.DrawableType

class FingerPath(paint: Paint): Drawable {
    override val type: DrawableType = DrawableType.FingerPath

    var pointList = mutableListOf<Point>()
    override var paint: Paint = paint
    override var size: Int = 0
    override fun onTouchDown(point: Point) {
       pointList.add(point)
    }

    override fun draw(canvas: Canvas) {
        pointList.forEach {
            canvas.drawCircle(it.x.toFloat(),it.y.toFloat(),paint.strokeWidth,paint)
        }
    }
}