package com.example.patryk.mobilepaint.drawable

enum class DrawableType {
    Circle,
    FingerPath,
    Line
}