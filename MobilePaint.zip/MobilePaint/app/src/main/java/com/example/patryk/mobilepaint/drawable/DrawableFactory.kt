package com.example.patryk.mobilepaint.drawable

import android.graphics.Paint
import com.example.patryk.mobilepaint.drawable.elements.Circle
import com.example.patryk.mobilepaint.drawable.elements.FingerPath
import com.example.patryk.mobilepaint.drawable.elements.Line

class DrawableFactory {
    companion object {

        fun createObject(paint: Paint, type: DrawableType): Drawable {
            return when (type) {
                DrawableType.Line -> {
                    makeLine(paint)
                }
                DrawableType.FingerPath -> {
                    makeFingerPath(paint)
                }
                DrawableType.Circle -> {
                    makeCircle(paint)
                }
            }
        }

        fun makeCircle(paint: Paint): Circle {
            return Circle(paint)
        }

        fun makeLine(paint: Paint): Line {
            return Line(paint)
        }

        fun makeFingerPath(paint: Paint): FingerPath {
            return FingerPath(paint)
        }
    }
}